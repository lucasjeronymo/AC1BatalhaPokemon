//Simulador de Batalhas Pokemon
//Desenvolvido por Lucas Jeronymo Ribeiro (210117) - ADS
package SimuladorPokemon;

import SimuladorPokemon.Pokemon;

public class SimuladorPokemon {
        public static void main(String[] args) {
        Pokemon P1 = new Pokemon("Raichu","Elétrico",55);
        Pokemon P2 = new Pokemon("Squirtle","Água",34);      
        
        int vidaP1 = P1.getHp();
        int vidaP2 = P2.getHp();
        
        if(vidaP1 > vidaP2){
            System.out.println(P1.getNome() + " venceu a batalha");
        } else{
            System.out.println(P2.getNome() + " venceu a batalha");
        }
}
        
}