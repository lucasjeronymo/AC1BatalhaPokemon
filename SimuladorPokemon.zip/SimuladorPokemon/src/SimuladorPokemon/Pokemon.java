//Calculos dos atributos dos pokemons
//Desenvolvido por Lucas Jeronymo Ribeiro (210117) - ADS
package SimuladorPokemon;

public class Pokemon {
    private String nome;
    private String elemento;
    private int lvl;
    private int hp;
    private int ataque;
    private int defesa;
    
    //CONSTRUTOR
    public Pokemon(String nome, String elemento, int lvl) {
        this.nome = nome;
        this.elemento = elemento;
        this.lvl = lvl;
        calcAtributos();
        calcBonus();
        imprimePokemon();
    }
         
    //MÉTODOS
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getElemento() {
        return elemento;
    }

    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }
    
    public void imprimePokemon(){
        System.out.println("Nome: " + nome + " | " +
                           "Elemento: " + elemento + " | " +
                           "Level: " + lvl + " | " +
                           "HP: " + hp + " | " +
                           "Ataque: " + ataque + " | " +
                           "Defesa: " + defesa + " | "
        );
    }
    
    public void calcAtributos(){
        switch(this.elemento){
            case "Fogo":
                this.hp = 100;
                this.ataque = 87;
                this.defesa = 25;
            break;
            
            case "Agua":
                this.hp = 80;
                this.ataque = 70;
                this.defesa = 40;
            break;
            
            case "Terra":
                this.hp = 110;
                this.ataque = 77;
                this.defesa = 90;
            break;
            
            case "Ar":
                this.hp = 50;
                this.ataque = 50;
                this.defesa = 18;
            break;
            
            case "Eletrico":
                this.hp = 90;
                this.ataque = 99;
                this.defesa = 44;
            break;            
        }
    }
    
    public void calcBonus(){
        hp = hp + (lvl / 2);
        ataque = ataque + (lvl / 2);
        defesa = defesa + (lvl / 3);
    }
    
}
